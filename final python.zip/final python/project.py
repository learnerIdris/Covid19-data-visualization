# This script performs data analysis and visualization on the CORD-19 dataset.
# It is designed to be run as a Streamlit web application.

# To run this script, you must first install the required libraries:
# pip install pandas streamlit matplotlib wordcloud scikit-learn

import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
from wordcloud import WordCloud
from collections import Counter
import re
import warnings

# Suppress the UserWarning from matplotlib when a figure is being used in Streamlit
warnings.filterwarnings('ignore', category=UserWarning)

# ---
# Part 1: Data Loading and Basic Exploration
# ---

# Define the file path for the metadata file.
# IMPORTANT: You must download 'metadata.csv' from the CORD-19 dataset
# and place it in the same directory as this script.
DATA_FILE = 'metadata.csv'

# Set up the Streamlit app title and description
st.title("🔬 CORD-19 Data Explorer")
st.markdown("A simple exploration of COVID-19 research papers using Streamlit.")

# Load the data into a pandas DataFrame. Use a try-except block to handle file errors.
try:
    df = pd.read_csv(DATA_FILE)
    st.success("Dataset loaded successfully!")
    
    # Display basic DataFrame information
    st.subheader("Data Overview")
    st.write(f"DataFrame dimensions: {df.shape[0]} rows, {df.shape[1]} columns")
    
    # Show the first few rows of the DataFrame
    if st.checkbox("Show raw data"):
        st.dataframe(df.head())

    # Check for missing values in key columns
    st.subheader("Missing Values Check")
    key_columns = ['publish_time', 'journal', 'title', 'abstract']
    missing_values = df[key_columns].isnull().sum().sort_values(ascending=False)
    st.write("Missing values in key columns:")
    st.dataframe(missing_values)

except FileNotFoundError:
    st.error(f"Error: The file '{DATA_FILE}' was not found.")
    st.info("Please download the metadata.csv file from the CORD-19 dataset and place it in the same folder as this script.")
    st.stop() # Stop the app execution if the file is not found

# ---
# Part 2: Data Cleaning and Preparation
# ---
st.subheader("Data Cleaning and Preparation")

# Drop rows where 'publish_time', 'journal', or 'title' are missing as they are crucial for the analysis.
df_cleaned = df.dropna(subset=['publish_time', 'journal', 'title']).copy()

# Convert the 'publish_time' column to a datetime object.
df_cleaned['publish_time'] = pd.to_datetime(df_cleaned['publish_time'], errors='coerce')

# Extract the year from the publication date for time-based analysis.
df_cleaned['year'] = df_cleaned['publish_time'].dt.year

# Create a new column for abstract word count.
df_cleaned['abstract_word_count'] = df_cleaned['abstract'].apply(lambda x: len(str(x).split()))

st.write(f"Cleaned DataFrame dimensions: {df_cleaned.shape[0]} rows, {df_cleaned.shape[1]} columns")

# ---
# Part 3: Data Analysis and Visualization
# ---

st.header("Data Analysis and Visualization")

# Filter data based on a Streamlit slider widget
st.sidebar.header("Filter Options")
# Find the min and max years in the dataset to set slider boundaries
min_year = int(df_cleaned['year'].min())
max_year = int(df_cleaned['year'].max())
year_range = st.sidebar.slider(
    "Select a year range for analysis",
    min_value=min_year,
    max_value=max_year,
    value=(min_year, max_year)
)

filtered_df = df_cleaned[(df_cleaned['year'] >= year_range[0]) & (df_cleaned['year'] <= year_range[1])]

# 1. Plot Number of Publications Over Time
st.subheader("Publications Over Time")
year_counts = filtered_df['year'].value_counts().sort_index()

fig1, ax1 = plt.subplots(figsize=(10, 6))
ax1.bar(year_counts.index, year_counts.values, color='skyblue')
ax1.set_title(f'Number of Publications by Year ({year_range[0]}-{year_range[1]})')
ax1.set_xlabel('Year')
ax1.set_ylabel('Number of Papers')
ax1.grid(axis='y', linestyle='--', alpha=0.7)
st.pyplot(fig1)

# 2. Plot Top 10 Publishing Journals
st.subheader("Top 10 Publishing Journals")
top_journals = filtered_df['journal'].value_counts().head(10)

fig2, ax2 = plt.subplots(figsize=(12, 8))
top_journals.plot(kind='barh', ax=ax2, color='lightcoral')
ax2.set_title(f'Top 10 Publishing Journals ({year_range[0]}-{year_range[1]})')
ax2.set_xlabel('Number of Papers')
ax2.set_ylabel('Journal')
ax2.invert_yaxis()  # Put the highest count at the top
st.pyplot(fig2)

# 3. Generate a Word Cloud of Paper Titles
st.subheader("Word Cloud of Paper Titles")
# Join all titles into a single string
all_titles = ' '.join(filtered_df['title'].str.lower().fillna(''))
# Simple cleaning: remove non-alphanumeric characters and extra spaces
all_titles = re.sub(r'[^a-z\s]', '', all_titles)

# Define common English stop words and add common research-related words
stopwords = ['the', 'and', 'of', 'in', 'a', 'to', 'for', 'with', 'from', 'on', 'as', 'by', 'an', 'is', 'at', 'or', 'are', 'this', 'that', 'from', 'using', 'study', 'report', 'paper', 'research', 'analysis', 'data', 'clinical', 'case', 'review']

word_freq = Counter(all_titles.split())
filtered_words = {word: count for word, count in word_freq.items() if word not in stopwords}

if filtered_words:
    wordcloud = WordCloud(width=800, height=400, background_color='white').generate_from_frequencies(filtered_words)
    
    fig3, ax3 = plt.subplots(figsize=(10, 5))
    ax3.imshow(wordcloud, interpolation='bilinear')
    ax3.axis("off")
    st.pyplot(fig3)
else:
    st.warning("No titles found for the selected year range to generate a word cloud.")

# ---
# Part 4: Displaying the App and Sample Data
# ---
st.subheader("Sample of Filtered Data")
# Display a sample of the cleaned data
st.dataframe(filtered_df[['title', 'journal', 'publish_time', 'abstract']].head(10))

# Display basic statistics of numerical columns in the filtered dataset
st.subheader("Basic Statistics")
st.dataframe(filtered_df[['year', 'abstract_word_count']].describe())

# End of script
